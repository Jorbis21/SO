#include <stdio.h>
#include <stdlib.h>
#include "archi.h"

int main(void)
{
	printf("Hello ...%d\n", VAR);
	exit(0);
}

